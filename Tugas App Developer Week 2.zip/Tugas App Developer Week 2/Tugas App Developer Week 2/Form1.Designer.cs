﻿namespace Tugas_App_Developer_Week_2
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Menu = new System.Windows.Forms.Panel();
            this.Next = new System.Windows.Forms.Button();
            this.t = new System.Windows.Forms.Label();
            this.r = new System.Windows.Forms.Label();
            this.e = new System.Windows.Forms.Label();
            this.w = new System.Windows.Forms.Label();
            this.q = new System.Windows.Forms.Label();
            this.Kata4 = new System.Windows.Forms.TextBox();
            this.Kata5 = new System.Windows.Forms.TextBox();
            this.Kata3 = new System.Windows.Forms.TextBox();
            this.Kata2 = new System.Windows.Forms.TextBox();
            this.Kata1 = new System.Windows.Forms.TextBox();
            this.Menu2 = new System.Windows.Forms.Panel();
            this.QQ = new System.Windows.Forms.Button();
            this.WW = new System.Windows.Forms.Button();
            this.RR = new System.Windows.Forms.Button();
            this.EE = new System.Windows.Forms.Button();
            this.YY = new System.Windows.Forms.Button();
            this.TT = new System.Windows.Forms.Button();
            this.II = new System.Windows.Forms.Button();
            this.UU = new System.Windows.Forms.Button();
            this.OO = new System.Windows.Forms.Button();
            this.PP = new System.Windows.Forms.Button();
            this.AA = new System.Windows.Forms.Button();
            this.JJ = new System.Windows.Forms.Button();
            this.GG = new System.Windows.Forms.Button();
            this.HH = new System.Windows.Forms.Button();
            this.FF = new System.Windows.Forms.Button();
            this.DD = new System.Windows.Forms.Button();
            this.SS = new System.Windows.Forms.Button();
            this.LL = new System.Windows.Forms.Button();
            this.KK = new System.Windows.Forms.Button();
            this.MM = new System.Windows.Forms.Button();
            this.NN = new System.Windows.Forms.Button();
            this.BB = new System.Windows.Forms.Button();
            this.VV = new System.Windows.Forms.Button();
            this.CC = new System.Windows.Forms.Button();
            this.XX = new System.Windows.Forms.Button();
            this.ZZ = new System.Windows.Forms.Button();
            this.Huruf1 = new System.Windows.Forms.Label();
            this.Huruf2 = new System.Windows.Forms.Label();
            this.Huruf5 = new System.Windows.Forms.Label();
            this.Huruf4 = new System.Windows.Forms.Label();
            this.Huruf3 = new System.Windows.Forms.Label();
            this.END = new System.Windows.Forms.Button();
            this.Menu.SuspendLayout();
            this.Menu2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Menu
            // 
            this.Menu.Controls.Add(this.Next);
            this.Menu.Controls.Add(this.t);
            this.Menu.Controls.Add(this.r);
            this.Menu.Controls.Add(this.e);
            this.Menu.Controls.Add(this.w);
            this.Menu.Controls.Add(this.q);
            this.Menu.Controls.Add(this.Kata4);
            this.Menu.Controls.Add(this.Kata5);
            this.Menu.Controls.Add(this.Kata3);
            this.Menu.Controls.Add(this.Kata2);
            this.Menu.Controls.Add(this.Kata1);
            this.Menu.Location = new System.Drawing.Point(12, 12);
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(200, 223);
            this.Menu.TabIndex = 34;
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(76, 171);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(75, 23);
            this.Next.TabIndex = 44;
            this.Next.Text = "Lanjut";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // t
            // 
            this.t.AutoSize = true;
            this.t.Cursor = System.Windows.Forms.Cursors.Default;
            this.t.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.t.Location = new System.Drawing.Point(25, 134);
            this.t.Name = "t";
            this.t.Size = new System.Drawing.Size(61, 24);
            this.t.TabIndex = 43;
            this.t.Text = "Kata 5";
            // 
            // r
            // 
            this.r.AutoSize = true;
            this.r.Cursor = System.Windows.Forms.Cursors.Default;
            this.r.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r.Location = new System.Drawing.Point(25, 108);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(61, 24);
            this.r.TabIndex = 42;
            this.r.Text = "Kata 4";
            // 
            // e
            // 
            this.e.AutoSize = true;
            this.e.Cursor = System.Windows.Forms.Cursors.Default;
            this.e.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e.Location = new System.Drawing.Point(25, 82);
            this.e.Name = "e";
            this.e.Size = new System.Drawing.Size(61, 24);
            this.e.TabIndex = 41;
            this.e.Text = "Kata 3";
            // 
            // w
            // 
            this.w.AutoSize = true;
            this.w.Cursor = System.Windows.Forms.Cursors.Default;
            this.w.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.w.Location = new System.Drawing.Point(25, 56);
            this.w.Name = "w";
            this.w.Size = new System.Drawing.Size(61, 24);
            this.w.TabIndex = 40;
            this.w.Text = "Kata 2";
            // 
            // q
            // 
            this.q.AutoSize = true;
            this.q.Cursor = System.Windows.Forms.Cursors.Default;
            this.q.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.q.Location = new System.Drawing.Point(25, 28);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(59, 24);
            this.q.TabIndex = 39;
            this.q.Text = "Kata 1";
            // 
            // Kata4
            // 
            this.Kata4.Location = new System.Drawing.Point(76, 106);
            this.Kata4.Name = "Kata4";
            this.Kata4.Size = new System.Drawing.Size(100, 20);
            this.Kata4.TabIndex = 38;
            // 
            // Kata5
            // 
            this.Kata5.Location = new System.Drawing.Point(76, 132);
            this.Kata5.Name = "Kata5";
            this.Kata5.Size = new System.Drawing.Size(100, 20);
            this.Kata5.TabIndex = 37;
            // 
            // Kata3
            // 
            this.Kata3.Location = new System.Drawing.Point(76, 80);
            this.Kata3.Name = "Kata3";
            this.Kata3.Size = new System.Drawing.Size(100, 20);
            this.Kata3.TabIndex = 36;
            // 
            // Kata2
            // 
            this.Kata2.Location = new System.Drawing.Point(76, 54);
            this.Kata2.Name = "Kata2";
            this.Kata2.Size = new System.Drawing.Size(100, 20);
            this.Kata2.TabIndex = 35;
            // 
            // Kata1
            // 
            this.Kata1.Location = new System.Drawing.Point(76, 28);
            this.Kata1.Name = "Kata1";
            this.Kata1.Size = new System.Drawing.Size(100, 20);
            this.Kata1.TabIndex = 34;
            // 
            // Menu2
            // 
            this.Menu2.Controls.Add(this.END);
            this.Menu2.Controls.Add(this.Huruf3);
            this.Menu2.Controls.Add(this.Huruf4);
            this.Menu2.Controls.Add(this.Huruf5);
            this.Menu2.Controls.Add(this.Huruf2);
            this.Menu2.Controls.Add(this.Huruf1);
            this.Menu2.Controls.Add(this.ZZ);
            this.Menu2.Controls.Add(this.XX);
            this.Menu2.Controls.Add(this.CC);
            this.Menu2.Controls.Add(this.VV);
            this.Menu2.Controls.Add(this.BB);
            this.Menu2.Controls.Add(this.NN);
            this.Menu2.Controls.Add(this.MM);
            this.Menu2.Controls.Add(this.KK);
            this.Menu2.Controls.Add(this.LL);
            this.Menu2.Controls.Add(this.SS);
            this.Menu2.Controls.Add(this.DD);
            this.Menu2.Controls.Add(this.FF);
            this.Menu2.Controls.Add(this.HH);
            this.Menu2.Controls.Add(this.GG);
            this.Menu2.Controls.Add(this.JJ);
            this.Menu2.Controls.Add(this.AA);
            this.Menu2.Controls.Add(this.PP);
            this.Menu2.Controls.Add(this.OO);
            this.Menu2.Controls.Add(this.UU);
            this.Menu2.Controls.Add(this.II);
            this.Menu2.Controls.Add(this.TT);
            this.Menu2.Controls.Add(this.YY);
            this.Menu2.Controls.Add(this.EE);
            this.Menu2.Controls.Add(this.RR);
            this.Menu2.Controls.Add(this.WW);
            this.Menu2.Controls.Add(this.QQ);
            this.Menu2.Location = new System.Drawing.Point(0, 12);
            this.Menu2.Name = "Menu2";
            this.Menu2.Size = new System.Drawing.Size(979, 444);
            this.Menu2.TabIndex = 35;
            // 
            // QQ
            // 
            this.QQ.Location = new System.Drawing.Point(75, 140);
            this.QQ.Name = "QQ";
            this.QQ.Size = new System.Drawing.Size(75, 68);
            this.QQ.TabIndex = 0;
            this.QQ.Text = "Q";
            this.QQ.UseVisualStyleBackColor = true;
            this.QQ.Click += new System.EventHandler(this.QQ_Click);
            // 
            // WW
            // 
            this.WW.Location = new System.Drawing.Point(156, 140);
            this.WW.Name = "WW";
            this.WW.Size = new System.Drawing.Size(75, 68);
            this.WW.TabIndex = 1;
            this.WW.Text = "W";
            this.WW.UseVisualStyleBackColor = true;
            this.WW.Click += new System.EventHandler(this.WW_Click);
            // 
            // RR
            // 
            this.RR.Location = new System.Drawing.Point(318, 140);
            this.RR.Name = "RR";
            this.RR.Size = new System.Drawing.Size(75, 68);
            this.RR.TabIndex = 2;
            this.RR.Text = "R";
            this.RR.UseVisualStyleBackColor = true;
            this.RR.Click += new System.EventHandler(this.RR_Click);
            // 
            // EE
            // 
            this.EE.Location = new System.Drawing.Point(237, 140);
            this.EE.Name = "EE";
            this.EE.Size = new System.Drawing.Size(75, 68);
            this.EE.TabIndex = 3;
            this.EE.Text = "E";
            this.EE.UseVisualStyleBackColor = true;
            this.EE.Click += new System.EventHandler(this.EE_Click);
            // 
            // YY
            // 
            this.YY.Location = new System.Drawing.Point(480, 140);
            this.YY.Name = "YY";
            this.YY.Size = new System.Drawing.Size(75, 68);
            this.YY.TabIndex = 4;
            this.YY.Text = "Y";
            this.YY.UseVisualStyleBackColor = true;
            this.YY.Click += new System.EventHandler(this.YY_Click);
            // 
            // TT
            // 
            this.TT.Location = new System.Drawing.Point(399, 140);
            this.TT.Name = "TT";
            this.TT.Size = new System.Drawing.Size(75, 68);
            this.TT.TabIndex = 5;
            this.TT.Text = "T";
            this.TT.UseVisualStyleBackColor = true;
            this.TT.Click += new System.EventHandler(this.TT_Click);
            // 
            // II
            // 
            this.II.Location = new System.Drawing.Point(642, 140);
            this.II.Name = "II";
            this.II.Size = new System.Drawing.Size(75, 68);
            this.II.TabIndex = 6;
            this.II.Text = "I";
            this.II.UseVisualStyleBackColor = true;
            this.II.Click += new System.EventHandler(this.II_Click);
            // 
            // UU
            // 
            this.UU.Location = new System.Drawing.Point(561, 140);
            this.UU.Name = "UU";
            this.UU.Size = new System.Drawing.Size(75, 68);
            this.UU.TabIndex = 7;
            this.UU.Text = "U";
            this.UU.UseVisualStyleBackColor = true;
            this.UU.Click += new System.EventHandler(this.UU_Click);
            // 
            // OO
            // 
            this.OO.Location = new System.Drawing.Point(723, 140);
            this.OO.Name = "OO";
            this.OO.Size = new System.Drawing.Size(75, 68);
            this.OO.TabIndex = 8;
            this.OO.Text = "O";
            this.OO.UseVisualStyleBackColor = true;
            this.OO.Click += new System.EventHandler(this.OO_Click);
            // 
            // PP
            // 
            this.PP.Location = new System.Drawing.Point(804, 140);
            this.PP.Name = "PP";
            this.PP.Size = new System.Drawing.Size(75, 68);
            this.PP.TabIndex = 9;
            this.PP.Text = "P";
            this.PP.UseVisualStyleBackColor = true;
            this.PP.Click += new System.EventHandler(this.PP_Click);
            // 
            // AA
            // 
            this.AA.Location = new System.Drawing.Point(112, 214);
            this.AA.Name = "AA";
            this.AA.Size = new System.Drawing.Size(75, 68);
            this.AA.TabIndex = 10;
            this.AA.Text = "A";
            this.AA.UseVisualStyleBackColor = true;
            this.AA.Click += new System.EventHandler(this.AA_Click);
            // 
            // JJ
            // 
            this.JJ.Location = new System.Drawing.Point(598, 214);
            this.JJ.Name = "JJ";
            this.JJ.Size = new System.Drawing.Size(75, 68);
            this.JJ.TabIndex = 11;
            this.JJ.Text = "J";
            this.JJ.UseVisualStyleBackColor = true;
            this.JJ.Click += new System.EventHandler(this.JJ_Click);
            // 
            // GG
            // 
            this.GG.Location = new System.Drawing.Point(436, 214);
            this.GG.Name = "GG";
            this.GG.Size = new System.Drawing.Size(75, 68);
            this.GG.TabIndex = 12;
            this.GG.Text = "G";
            this.GG.UseVisualStyleBackColor = true;
            this.GG.Click += new System.EventHandler(this.GG_Click);
            // 
            // HH
            // 
            this.HH.Location = new System.Drawing.Point(517, 214);
            this.HH.Name = "HH";
            this.HH.Size = new System.Drawing.Size(75, 68);
            this.HH.TabIndex = 13;
            this.HH.Text = "H";
            this.HH.UseVisualStyleBackColor = true;
            this.HH.Click += new System.EventHandler(this.HH_Click);
            // 
            // FF
            // 
            this.FF.Location = new System.Drawing.Point(355, 214);
            this.FF.Name = "FF";
            this.FF.Size = new System.Drawing.Size(75, 68);
            this.FF.TabIndex = 14;
            this.FF.Text = "F";
            this.FF.UseVisualStyleBackColor = true;
            this.FF.Click += new System.EventHandler(this.FF_Click);
            // 
            // DD
            // 
            this.DD.Location = new System.Drawing.Point(274, 214);
            this.DD.Name = "DD";
            this.DD.Size = new System.Drawing.Size(75, 68);
            this.DD.TabIndex = 15;
            this.DD.Text = "D";
            this.DD.UseVisualStyleBackColor = true;
            this.DD.Click += new System.EventHandler(this.DD_Click);
            // 
            // SS
            // 
            this.SS.Location = new System.Drawing.Point(193, 214);
            this.SS.Name = "SS";
            this.SS.Size = new System.Drawing.Size(75, 68);
            this.SS.TabIndex = 16;
            this.SS.Text = "S";
            this.SS.UseVisualStyleBackColor = true;
            this.SS.Click += new System.EventHandler(this.SS_Click);
            // 
            // LL
            // 
            this.LL.Location = new System.Drawing.Point(760, 214);
            this.LL.Name = "LL";
            this.LL.Size = new System.Drawing.Size(75, 68);
            this.LL.TabIndex = 17;
            this.LL.Text = "L";
            this.LL.UseVisualStyleBackColor = true;
            this.LL.Click += new System.EventHandler(this.LL_Click);
            // 
            // KK
            // 
            this.KK.Location = new System.Drawing.Point(679, 214);
            this.KK.Name = "KK";
            this.KK.Size = new System.Drawing.Size(75, 68);
            this.KK.TabIndex = 18;
            this.KK.Text = "K";
            this.KK.UseVisualStyleBackColor = true;
            this.KK.Click += new System.EventHandler(this.KK_Click);
            // 
            // MM
            // 
            this.MM.Location = new System.Drawing.Point(679, 288);
            this.MM.Name = "MM";
            this.MM.Size = new System.Drawing.Size(75, 68);
            this.MM.TabIndex = 19;
            this.MM.Text = "M";
            this.MM.UseVisualStyleBackColor = true;
            this.MM.Click += new System.EventHandler(this.MM_Click);
            // 
            // NN
            // 
            this.NN.Location = new System.Drawing.Point(598, 288);
            this.NN.Name = "NN";
            this.NN.Size = new System.Drawing.Size(75, 68);
            this.NN.TabIndex = 20;
            this.NN.Text = "N";
            this.NN.UseVisualStyleBackColor = true;
            this.NN.Click += new System.EventHandler(this.NN_Click);
            // 
            // BB
            // 
            this.BB.Location = new System.Drawing.Point(517, 288);
            this.BB.Name = "BB";
            this.BB.Size = new System.Drawing.Size(75, 68);
            this.BB.TabIndex = 21;
            this.BB.Text = "B";
            this.BB.UseVisualStyleBackColor = true;
            this.BB.Click += new System.EventHandler(this.BB_Click);
            // 
            // VV
            // 
            this.VV.Location = new System.Drawing.Point(436, 288);
            this.VV.Name = "VV";
            this.VV.Size = new System.Drawing.Size(75, 68);
            this.VV.TabIndex = 22;
            this.VV.Text = "V";
            this.VV.UseVisualStyleBackColor = true;
            this.VV.Click += new System.EventHandler(this.VV_Click);
            // 
            // CC
            // 
            this.CC.Location = new System.Drawing.Point(355, 288);
            this.CC.Name = "CC";
            this.CC.Size = new System.Drawing.Size(75, 68);
            this.CC.TabIndex = 23;
            this.CC.Text = "C";
            this.CC.UseVisualStyleBackColor = true;
            this.CC.Click += new System.EventHandler(this.CC_Click);
            // 
            // XX
            // 
            this.XX.Location = new System.Drawing.Point(274, 288);
            this.XX.Name = "XX";
            this.XX.Size = new System.Drawing.Size(75, 68);
            this.XX.TabIndex = 24;
            this.XX.Text = "X";
            this.XX.UseVisualStyleBackColor = true;
            this.XX.Click += new System.EventHandler(this.XX_Click);
            // 
            // ZZ
            // 
            this.ZZ.Location = new System.Drawing.Point(193, 288);
            this.ZZ.Name = "ZZ";
            this.ZZ.Size = new System.Drawing.Size(75, 68);
            this.ZZ.TabIndex = 25;
            this.ZZ.Text = "Z";
            this.ZZ.UseVisualStyleBackColor = true;
            this.ZZ.Click += new System.EventHandler(this.ZZ_Click);
            // 
            // Huruf1
            // 
            this.Huruf1.AutoSize = true;
            this.Huruf1.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huruf1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Huruf1.Location = new System.Drawing.Point(323, 33);
            this.Huruf1.Name = "Huruf1";
            this.Huruf1.Size = new System.Drawing.Size(58, 67);
            this.Huruf1.TabIndex = 26;
            this.Huruf1.Text = "_";
            // 
            // Huruf2
            // 
            this.Huruf2.AutoSize = true;
            this.Huruf2.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huruf2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Huruf2.Location = new System.Drawing.Point(387, 33);
            this.Huruf2.Name = "Huruf2";
            this.Huruf2.Size = new System.Drawing.Size(58, 67);
            this.Huruf2.TabIndex = 27;
            this.Huruf2.Text = "_";
            // 
            // Huruf5
            // 
            this.Huruf5.AutoSize = true;
            this.Huruf5.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huruf5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Huruf5.Location = new System.Drawing.Point(578, 33);
            this.Huruf5.Name = "Huruf5";
            this.Huruf5.Size = new System.Drawing.Size(58, 67);
            this.Huruf5.TabIndex = 28;
            this.Huruf5.Text = "_";
            // 
            // Huruf4
            // 
            this.Huruf4.AutoSize = true;
            this.Huruf4.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huruf4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Huruf4.Location = new System.Drawing.Point(514, 33);
            this.Huruf4.Name = "Huruf4";
            this.Huruf4.Size = new System.Drawing.Size(58, 67);
            this.Huruf4.TabIndex = 29;
            this.Huruf4.Text = "_";
            // 
            // Huruf3
            // 
            this.Huruf3.AutoSize = true;
            this.Huruf3.Font = new System.Drawing.Font("Comic Sans MS", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huruf3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Huruf3.Location = new System.Drawing.Point(450, 33);
            this.Huruf3.Name = "Huruf3";
            this.Huruf3.Size = new System.Drawing.Size(58, 67);
            this.Huruf3.TabIndex = 30;
            this.Huruf3.Text = "_";
            // 
            // END
            // 
            this.END.Font = new System.Drawing.Font("Comic Sans MS", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.END.Location = new System.Drawing.Point(804, 28);
            this.END.Name = "END";
            this.END.Size = new System.Drawing.Size(145, 68);
            this.END.TabIndex = 31;
            this.END.Text = "END";
            this.END.UseVisualStyleBackColor = true;
            this.END.Click += new System.EventHandler(this.END_Click);
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(982, 453);
            this.Controls.Add(this.Menu2);
            this.Controls.Add(this.Menu);
            this.Name = "Game";
            this.Text = "Tebak-Tebak";
            this.Menu.ResumeLayout(false);
            this.Menu.PerformLayout();
            this.Menu2.ResumeLayout(false);
            this.Menu2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Menu;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Label t;
        private System.Windows.Forms.Label r;
        private System.Windows.Forms.Label e;
        private System.Windows.Forms.Label w;
        private System.Windows.Forms.Label q;
        private System.Windows.Forms.TextBox Kata4;
        private System.Windows.Forms.TextBox Kata5;
        private System.Windows.Forms.TextBox Kata3;
        private System.Windows.Forms.TextBox Kata2;
        private System.Windows.Forms.TextBox Kata1;
        private System.Windows.Forms.Panel Menu2;
        private System.Windows.Forms.Button QQ;
        private System.Windows.Forms.Button OO;
        private System.Windows.Forms.Button UU;
        private System.Windows.Forms.Button II;
        private System.Windows.Forms.Button TT;
        private System.Windows.Forms.Button YY;
        private System.Windows.Forms.Button EE;
        private System.Windows.Forms.Button RR;
        private System.Windows.Forms.Button WW;
        private System.Windows.Forms.Button PP;
        private System.Windows.Forms.Button KK;
        private System.Windows.Forms.Button LL;
        private System.Windows.Forms.Button SS;
        private System.Windows.Forms.Button DD;
        private System.Windows.Forms.Button FF;
        private System.Windows.Forms.Button HH;
        private System.Windows.Forms.Button GG;
        private System.Windows.Forms.Button JJ;
        private System.Windows.Forms.Button AA;
        private System.Windows.Forms.Button ZZ;
        private System.Windows.Forms.Button XX;
        private System.Windows.Forms.Button CC;
        private System.Windows.Forms.Button VV;
        private System.Windows.Forms.Button BB;
        private System.Windows.Forms.Button NN;
        private System.Windows.Forms.Button MM;
        private System.Windows.Forms.Label Huruf1;
        private System.Windows.Forms.Label Huruf3;
        private System.Windows.Forms.Label Huruf4;
        private System.Windows.Forms.Label Huruf5;
        private System.Windows.Forms.Label Huruf2;
        private System.Windows.Forms.Button END;
    }
}

