﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Tugas_App_Developer_Week_2
{
    public partial class Game : System.Windows.Forms.Form
    {
        public Game()
        {
            InitializeComponent();
            Menu2.Visible = false;
           
        }
        public static class Global
        {
            public static string[] Huruf = new string[6];
            public static char[] Tulisan = new char[6];
            public static int Benar = 0;
        }
        private void Next_Click(object sender, EventArgs e)
        {
            
            string KataKata1 = Convert.ToString(Kata1.Text);
            string KataKata2 = Convert.ToString(Kata2.Text);
            string KataKata3 = Convert.ToString(Kata3.Text);
            string KataKata4 = Convert.ToString(Kata4.Text);
            string KataKata5 = Convert.ToString(Kata5.Text);
            int Panjang1 = KataKata1.Length;
            int Panjang2 = KataKata2.Length;
            int Panjang3 = KataKata3.Length;
            int Panjang4 = KataKata4.Length;
            int Panjang5 = KataKata5.Length;
            string Angka = "0123456789";
            int CekAngka = 0;
            int Error = 0;
            if (Panjang1 != 5 || Panjang2 != 5 || Panjang3 != 5 || Panjang4 != 5 || Panjang5 != 5)
            {
                Error++;
                MessageBox.Show("Setiap Box harus berisi 5 kata");
            }
            foreach (char asem in KataKata1)
            {
                if (Angka.Contains(asem))
                {
                    CekAngka++;
                }

            }
            foreach (char asem in KataKata2)
            {
                if (Angka.Contains(asem))
                {
                    CekAngka++;
                }
            }
            foreach (char asem in KataKata3)
            {
                if (Angka.Contains(asem))
                {
                    CekAngka++;
                }

            }
            foreach (char asem in KataKata4)
            {
                if (Angka.Contains(asem))
                {
                    CekAngka++;
                }

            }
            foreach (char asem in KataKata5)
            {
                if (Angka.Contains(asem))
                {
                    CekAngka++;
                }

            }
            if (CekAngka != 0)
            {
                Error++;
                MessageBox.Show("Tidak Boleh Angka");
            }

            if (KataKata1 == KataKata2 || KataKata1 == KataKata3 || KataKata1 == KataKata4 || KataKata1 == KataKata5 || KataKata2 == KataKata1 || KataKata2 == KataKata1 || KataKata2 == KataKata3 || KataKata2 == KataKata4 || KataKata2 == KataKata5 || KataKata3 == KataKata1 || KataKata3 == KataKata2 || KataKata3 == KataKata4 || KataKata3 == KataKata5 || KataKata4 == KataKata1 || KataKata4 == KataKata2 || KataKata4 == KataKata3 || KataKata4 == KataKata5 || KataKata5 == KataKata1 || KataKata5 == KataKata2 || KataKata5 == KataKata3 || KataKata5 == KataKata4)
            {
                Error++;
                MessageBox.Show("Tidak boleh ada kata yang kembar");
            }
            if (Error == 0)
            {
                Menu.Visible = false;
                this.Size = new Size(1000, 500);
                Menu2.Visible = true;
                Global.Huruf[0] = KataKata1.ToUpper();
                Global.Huruf[1] = KataKata2.ToUpper();
                Global.Huruf[2] = KataKata3.ToUpper();
                Global.Huruf[3] = KataKata4.ToUpper();
                Global.Huruf[4] = KataKata5.ToUpper();
                Random random = new Random();
                int Random = random.Next(Global.Huruf.Length);
                string Terpilih = Global.Huruf[Random];
                Global.Huruf[5] = Terpilih;

                int Nomor = 1;
                foreach (char Huruf in Terpilih)
                {
                    Global.Tulisan[Nomor] = Huruf;
                    Nomor++;
                }
            }

        }

        private void QQ_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'Q')
            {
                Huruf1.Text = "Q";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'Q')
            {
                Huruf2.Text = "Q";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'Q')
            {
                Huruf3.Text = "Q";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'Q')
            {
                Huruf4.Text = "Q";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'Q')
            {
                Huruf5.Text = "Q";
                Global.Benar++;
            }
        }

        private void WW_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'W')
            {
                Huruf1.Text = "W";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'W')
            {
                Huruf2.Text = "W";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'W')
            {
                Huruf3.Text = "W";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'W')
            {
                Huruf4.Text = "W";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'W')
            {
                Huruf5.Text = "W";
                Global.Benar++;
            }
        }

        private void EE_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'E')
            {
                Huruf1.Text = "E";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'E')
            {
                Huruf2.Text = "E";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'E')
            {
                Huruf3.Text = "E";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'E')
            {
                Huruf4.Text = "E";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'E')
            {
                Huruf5.Text = "E";
                Global.Benar++;
            }
        }

        private void RR_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'R')
            {
                Huruf1.Text = "R";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'R')
            {
                Huruf2.Text = "R";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'R')
            {
                Huruf3.Text = "R";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'R')
            {
                Huruf4.Text = "R";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'R')
            {
                Huruf5.Text = "R";
                Global.Benar++;
            }
        }

        private void TT_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'T')
            {
                Huruf1.Text = "T";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'T')
            {
                Huruf2.Text = "T";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'T')
            {
                Huruf3.Text = "T";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'T')
            {
                Huruf4.Text = "T";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'T')
            {
                Huruf5.Text = "T";
                Global.Benar++;
            }
        }


        private void YY_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'Y')
            {
                Huruf1.Text = "Y";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'Y')
            {
                Huruf2.Text = "Y";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'Y')
            {
                Huruf3.Text = "Y";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'Y')
            {
                Huruf4.Text = "Y";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'Y')
            {
                Huruf5.Text = "Y";
                Global.Benar++;
            }
        }

        private void UU_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'U')
            {
                Huruf1.Text = "U";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'U')
            {
                Huruf2.Text = "U";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'U')
            {
                Huruf3.Text = "U";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'U')
            {
                Huruf4.Text = "U";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'U')
            {
                Huruf5.Text = "U";
                Global.Benar++;
            }
        }

        private void II_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'I')
            {
                Huruf1.Text = "I";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'I')
            {
                Huruf2.Text = "I";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'I')
            {
                Huruf3.Text = "I";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'I')
            {
                Huruf4.Text = "I";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'I')
            {
                Huruf5.Text = "I";
                Global.Benar++;
            }
        }


        private void OO_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'O')
            {
                Huruf1.Text = "O";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'O')
            {
                Huruf2.Text = "O";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'O')
            {
                Huruf3.Text = "O";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'O')
            {
                Huruf4.Text = "O";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'O')
            {
                Huruf5.Text = "O";
                Global.Benar++;
            }
        }

        private void PP_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'P')
            {
                Huruf1.Text = "P";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'P')
            {
                Huruf2.Text = "P";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'P')
            {
                Huruf3.Text = "P";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'P')
            {
                Huruf4.Text = "P";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'P')
            {
                Huruf5.Text = "P";
                Global.Benar++;
            }
        }

        private void AA_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'A')
            {
                Huruf1.Text = "A";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'A')
            {
                Huruf2.Text = "A";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'A')
            {
                Huruf3.Text = "A";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'A')
            {
                Huruf4.Text = "A";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'A')
            {
                Huruf5.Text = "A";
                Global.Benar++;
            }
        }

        private void SS_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'S')
            {
                Huruf1.Text = "S";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'S')
            {
                Huruf2.Text = "S";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'S')
            {
                Huruf3.Text = "S";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'S')
            {
                Huruf4.Text = "S";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'S')
            {
                Huruf5.Text = "S";
                Global.Benar++;
            }
        }

        private void DD_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'D')
            {
                Huruf1.Text = "D";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'D')
            {
                Huruf2.Text = "D";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'D')
            {
                Huruf3.Text = "D";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'D')
            {
                Huruf4.Text = "D";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'D')
            {
                Huruf5.Text = "D";
                Global.Benar++;
            }
        }

        private void FF_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'F')
            {
                Huruf1.Text = "F";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'F')
            {
                Huruf2.Text = "F";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'F')
            {
                Huruf3.Text = "F";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'F')
            {
                Huruf4.Text = "F";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'F')
            {
                Huruf5.Text = "F";
                Global.Benar++;
            }
        }


        private void GG_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'G')
            {
                Huruf1.Text = "G";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'G')
            {
                Huruf2.Text = "G";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'G')
            {
                Huruf3.Text = "G";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'G')
            {
                Huruf4.Text = "G";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'G')
            {
                Huruf5.Text = "G";
                Global.Benar++;
            }
        }

        private void HH_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'H')
            {
                Huruf1.Text = "H";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'H')
            {
                Huruf2.Text = "H";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'H')
            {
                Huruf3.Text = "H";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'H')
            {
                Huruf4.Text = "H";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'H')
            {
                Huruf5.Text = "H";
                Global.Benar++;
            }
        }

        private void JJ_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'J')
            {
                Huruf1.Text = "J";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'J')
            {
                Huruf2.Text = "J";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'J')
            {
                Huruf3.Text = "J";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'J')
            {
                Huruf4.Text = "J";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'J')
            {
                Huruf5.Text = "J";
                Global.Benar++;
            }
        }

        private void KK_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'K')
            {
                Huruf1.Text = "K";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'K')
            {
                Huruf2.Text = "K";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'K')
            {
                Huruf3.Text = "K";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'K')
            {
                Huruf4.Text = "K";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'K')
            {
                Huruf5.Text = "K";
                Global.Benar++;
            }
        }

        private void LL_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'L')
            {
                Huruf1.Text = "L";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'L')
            {
                Huruf2.Text = "L";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'L')
            {
                Huruf3.Text = "L";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'L')
            {
                Huruf4.Text = "L";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'L')
            {
                Huruf5.Text = "L";
                Global.Benar++;
            }
        }

        private void ZZ_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'Z')
            {
                Huruf1.Text = "Z";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'Z')
            {
                Huruf2.Text = "Z";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'Z')
            {
                Huruf3.Text = "Z";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'Z')
            {
                Huruf4.Text = "Z";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'Z')
            {
                Huruf5.Text = "Z";
                Global.Benar++;
            }
        }

        private void XX_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'X')
            {
                Huruf1.Text = "X";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'X')
            {
                Huruf2.Text = "X";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'X')
            {
                Huruf3.Text = "X";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'X')
            {
                Huruf4.Text = "X";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'X')
            {
                Huruf5.Text = "X";
                Global.Benar++;
            }
        }

        private void CC_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'C')
            {
                Huruf1.Text = "C";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'C')
            {
                Huruf2.Text = "C";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'C')
            {
                Huruf3.Text = "C";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'C')
            {
                Huruf4.Text = "C";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'C')
            {
                Huruf5.Text = "C";
                Global.Benar++;
            }
        }

        private void VV_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'V')
            {
                Huruf1.Text = "V";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'V')
            {
                Huruf2.Text = "V";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'V')
            {
                Huruf3.Text = "V";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'V')
            {
                Huruf4.Text = "V";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'V')
            {
                Huruf5.Text = "V";
                Global.Benar++;
            }
        }

        private void BB_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'B')
            {
                Huruf1.Text = "B";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'B')
            {
                Huruf2.Text = "B";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'B')
            {
                Huruf3.Text = "B";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'B')
            {
                Huruf4.Text = "B";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'B')
            {
                Huruf5.Text = "B";
                Global.Benar++;
            }
        }

        private void NN_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'N')
            {
                Huruf1.Text = "N";
                Global.Benar++;
            }
             if (Global.Tulisan[2] == 'N')
            {
                Huruf2.Text = "N";
                Global.Benar++;
            }
             if (Global.Tulisan[3] == 'N')
            {
                Huruf3.Text = "N";
                Global.Benar++;
            }
             if (Global.Tulisan[4] == 'N')
            {
                Huruf4.Text = "N";
                Global.Benar++;
            }
             if (Global.Tulisan[5] == 'N')
            {
                Huruf5.Text = "N";
                Global.Benar++;
            }
        }

        private void MM_Click(object sender, EventArgs e)
        {
            if (Global.Tulisan[1] == 'M')
            {
                Huruf1.Text = "M";
                Global.Benar++;
            }
            if (Global.Tulisan[2] == 'M')
            {
                Huruf2.Text = "M";
                Global.Benar++;
            }
            if (Global.Tulisan[3] == 'M')
            {
                Huruf3.Text = "M";
                Global.Benar++;
            }
            if (Global.Tulisan[4] == 'M')
            {
                Huruf4.Text = "M";
                Global.Benar++;
            }
            if (Global.Tulisan[5] == 'M')
            {
                Huruf5.Text = "M";
                Global.Benar++;
            }
        }

        private void END_Click(object sender, EventArgs e)
        {
            if (Global.Benar >= 5)
            {
                MessageBox.Show("Selamat Anda Menang");
            }
            else if (Global.Benar <= 5)
            {
                MessageBox.Show("Anda Kalah");
            }
        }
    }
}
